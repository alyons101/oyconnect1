import React, { useEffect } from 'react';
import { User } from '@/api/entities';
import { Message } from '@/api/entities';

const NotificationManager = () => {
    useEffect(() => {
        let interval;
        let lastCheckTime = new Date();

        const checkForNewMessages = async () => {
            try {
                const currentUser = await User.me();
                
                // OPTIMIZATION: Only check for very recent messages (last 5 minutes)
                const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
                const recentMessages = await Message.filter({
                    participants: { "$in": [currentUser.id] },
                    created_date: { $gt: fiveMinutesAgo.toISOString() },
                    sender_id: { $ne: currentUser.id },
                    read: false
                }, "-created_date", 5); // Only get last 5 messages
                
                if (recentMessages.length > 0) {
                    const connectionGroups = new Map();
                    recentMessages.forEach(msg => {
                        if (!connectionGroups.has(msg.connection_id)) {
                            connectionGroups.set(msg.connection_id, msg);
                        }
                    });

                    for (const [, latestMessage] of connectionGroups) {
                        try {
                            const otherUser = await User.get(latestMessage.sender_id);
                            showNotification(otherUser, latestMessage);
                        } catch (e) {
                            console.warn("Could not get user for notification");
                        }
                    }
                }
                
                lastCheckTime = new Date();
            } catch (error) {
                // Ignore auth errors, but log others
                if (error.response?.status !== 401 && error.response?.status !== 429) {
                   console.error("Error checking for new messages:", error);
                }
            }
        };

        const showNotification = (sender, message) => {
            if (!('Notification' in window) || Notification.permission !== 'granted') return;

            // Don't show notification if user is already on that chat page
            const currentPath = window.location.pathname;
            const currentConnectionId = new URLSearchParams(window.location.search).get('id');
            if (currentPath.includes('/Chat') && message.connection_id === currentConnectionId) return;

            const notification = new Notification(`New message from ${sender.first_name}`, {
                body: message.content.length > 50 
                    ? message.content.substring(0, 50) + '...' 
                    : message.content,
                icon: sender.profile_photo || '/favicon.ico',
                tag: `message-${message.connection_id}`,
                renotify: true,
            });
            
            setTimeout(() => notification.close(), 5000);

            notification.onclick = () => {
                window.location.href = `/Chat?id=${message.connection_id}`;
                window.focus();
                notification.close();
            };
        };

        const requestPermission = async () => {
          if ('Notification' in window && Notification.permission === 'default') {
            await Notification.requestPermission();
          }
        };

        requestPermission();
        
        // OPTIMIZATION: Much less frequent polling for background notifications (10 minutes)
        interval = setInterval(checkForNewMessages, 600000); 
        
        return () => clearInterval(interval);
    }, []);

    return null;
};

export default NotificationManager;