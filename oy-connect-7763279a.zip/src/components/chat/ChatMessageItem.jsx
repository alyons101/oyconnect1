import React from 'react';
import { format } from 'date-fns';

export default function ChatMessageItem({ message, isSender }) {
  const alignment = isSender ? 'justify-end' : 'justify-start';
  const bubbleColor = isSender 
    ? 'bg-primary text-primary-foreground' 
    : 'bg-card border';
  const borderRadius = isSender 
    ? 'rounded-t-2xl rounded-bl-2xl' 
    : 'rounded-t-2xl rounded-br-2xl';

  return (
    <div className={`flex ${alignment} items-end gap-2`}>
      <div className={`max-w-xs md:max-w-md p-3 ${bubbleColor} ${borderRadius} shadow-sm`}>
        <p className="whitespace-pre-wrap break-words">{message.content}</p>
        <p className={`text-xs mt-1 ${isSender ? 'text-primary-foreground/70' : 'text-muted-foreground'} text-right`}>
            {format(new Date(message.created_date), 'HH:mm')}
        </p>
      </div>
    </div>
  );
}