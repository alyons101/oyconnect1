import React, { useEffect, useRef } from 'react';
import ChatMessageItem from './ChatMessageItem';
import { motion, AnimatePresence } from 'framer-motion';

export default function ChatMessages({ messages, currentUser }) {
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence initial={false}>
            {messages.map((message, index) => (
                <motion.div
                    key={message.id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2, delay: 0.05 * (index - (messages.length - 2))}}
                >
                    <ChatMessageItem 
                        message={message} 
                        isSender={message.sender_id === currentUser.id} 
                    />
                </motion.div>
            ))}
        </AnimatePresence>
    </div>
  );
}