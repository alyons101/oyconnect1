import React, { useState } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { SendHorizonal } from 'lucide-react';

export default function MessageInput({ onSendMessage }) {
  const [content, setContent] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (content.trim()) {
      onSendMessage(content.trim());
      setContent('');
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSubmit(e);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="p-3 flex items-start gap-3">
      <Textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Type a message..."
        className="flex-1 min-h-[48px] max-h-32 resize-none rounded-2xl border-border/80 focus-visible:ring-1 focus-visible:ring-primary"
        rows={1}
      />
      <Button 
        type="submit" 
        size="icon" 
        className="rounded-full w-12 h-12 flex-shrink-0 bg-primary hover:bg-primary/90"
        disabled={!content.trim()}
      >
        <SendHorizonal className="w-6 h-6" />
      </Button>
    </form>
  );
}