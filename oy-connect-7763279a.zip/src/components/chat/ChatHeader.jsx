import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, MoreVertical, ShieldAlert, Trash2 } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from '@/components/ui/button';
import OptimizedAvatar from '../OptimizedAvatar';
import { toast } from "sonner";

export default function ChatHeader({ otherUser, onBlock }) {
  const navigate = useNavigate();

  const handleReport = () => {
    toast.info("Thank you for your report.", {
        description: "Our team will review this chat. You can also block this user to stop all communication.",
    });
  };

  return (
    <header className="sticky top-0 z-10 bg-card/80 backdrop-blur-md border-b border-border/50 safe-padding-top">
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" className="rounded-full" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <div className="flex items-center gap-3">
            <OptimizedAvatar
              src={otherUser?.profile_photo}
              alt={otherUser?.first_name}
              fallbackText={otherUser?.first_name?.[0]}
              className="w-10 h-10"
            />
            <div>
              <h2 className="font-bold text-lg">{otherUser?.first_name}</h2>
              <p className="text-xs text-muted-foreground">Online</p>
            </div>
          </div>
        </div>

        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                    <MoreVertical className="w-5 h-5" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleReport}>
                    <ShieldAlert className="mr-2 h-4 w-4" />
                    <span>Report Chat</span>
                </DropdownMenuItem>
                <AlertDialog>
                    <AlertDialogTrigger asChild>
                        <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                            <Trash2 className="mr-2 h-4 w-4 text-destructive" />
                            <span className="text-destructive">Block User</span>
                        </DropdownMenuItem>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                        <AlertDialogHeader>
                            <AlertDialogTitle>Block {otherUser?.first_name}?</AlertDialogTitle>
                            <AlertDialogDescription>
                                You will stop receiving messages from them and they will be removed from your Discover page. This cannot be undone.
                            </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={onBlock} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                                Block
                            </AlertDialogAction>
                        </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}