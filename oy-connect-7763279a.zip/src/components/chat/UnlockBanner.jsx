
import React, { useState, useEffect } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Phone, Check, Clock, Lock, MessageSquare, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Connection } from "@/api/entities";
import { Message } from "@/api/entities";
import { toast } from "sonner";

const UnlockBanner = ({ connection, currentUser, otherUser, onUnlockStatusChange }) => {
    const [unlockStatus, setUnlockStatus] = useState('not_eligible');
    const [isLoading, setIsLoading] = useState(false);
    const [hasMessages, setHasMessages] = useState(false);

    // Early return if required props are missing
    if (!connection || !currentUser || !otherUser) {
        return null;
    }

    // Check eligibility and current status
    useEffect(() => {
        const checkUnlockEligibility = async () => {
            try {
                // Check if both users have sent at least one message
                const messages = await Message.filter({ connection_id: connection.id });
                const currentUserMessages = messages.filter(m => m.sender_id === currentUser.id);
                const otherUserMessages = messages.filter(m => m.sender_id === otherUser.id);
                
                const bothHaveMessaged = currentUserMessages.length > 0 && otherUserMessages.length > 0;
                setHasMessages(bothHaveMessaged);

                // Check if both users have phone numbers - now with null safety
                const bothHaveNumbers = currentUser?.phone_number && otherUser?.phone_number;

                // Check if both users allow mutual unlock - now with null safety
                const bothAllowUnlock = currentUser?.allow_mutual_unlock !== false && otherUser?.allow_mutual_unlock !== false;

                if (!bothHaveMessaged || !bothHaveNumbers || !bothAllowUnlock) {
                    setUnlockStatus('not_eligible');
                    return;
                }

                // Check current unlock status
                const unlockAgreements = connection.unlock_agreements || [];
                const currentUserAgreed = unlockAgreements.includes(currentUser.id);
                const otherUserAgreed = unlockAgreements.includes(otherUser.id);

                if (connection.numbers_unlocked) {
                    setUnlockStatus('unlocked');
                } else if (currentUserAgreed && otherUserAgreed) {
                    setUnlockStatus('both_agreed');
                } else if (currentUserAgreed) {
                    setUnlockStatus('waiting_for_other');
                } else if (otherUserAgreed) {
                    setUnlockStatus('other_waiting');
                } else {
                    setUnlockStatus('eligible');
                }
            } catch (error) {
                console.error('Error checking unlock eligibility:', error);
                setUnlockStatus('not_eligible');
            }
        };

        // Only run if we have all required data
        if (connection?.id && currentUser?.id && otherUser?.id) {
            checkUnlockEligibility();
        }
    }, [connection, currentUser, otherUser]);

    const handleUnlockRequest = async () => {
        if (!currentUser?.id || !otherUser?.id || !connection?.id) {
            toast.error("Unable to process unlock request. Please refresh and try again.");
            return;
        }

        setIsLoading(true);
        try {
            const unlockAgreements = connection.unlock_agreements || [];
            const newAgreements = [...unlockAgreements, currentUser.id];
            
            await Connection.update(connection.id, {
                unlock_agreements: newAgreements
            });

            // Check if both users have now agreed
            const otherUserAgreed = unlockAgreements.includes(otherUser.id);
            if (otherUserAgreed) {
                // Both have agreed, unlock the numbers
                await Connection.update(connection.id, {
                    numbers_unlocked: true
                });
                setUnlockStatus('unlocked');
                toast.success("Numbers unlocked! 🎉", {
                    description: "Both of you can now see each other's WhatsApp numbers."
                });
                onUnlockStatusChange?.('unlocked');
            } else {
                setUnlockStatus('waiting_for_other');
                toast.success("Unlock request sent!", {
                    description: `Waiting for ${otherUser.first_name || 'them'} to agree.`
                });
                onUnlockStatusChange?.('waiting_for_other');
            }
        } catch (error) {
            console.error('Error requesting unlock:', error);
            toast.error("Failed to send unlock request. Please try again.");
        } finally {
            setIsLoading(false);
        }
    };

    const getStatusContent = () => {
        // Additional null safety checks within getStatusContent
        if (!currentUser || !otherUser) {
            return null;
        }

        switch (unlockStatus) {
            case 'not_eligible':
                const missingMessages = !hasMessages;
                const missingNumbers = !currentUser?.phone_number || !otherUser?.phone_number;
                const disabledByUser = currentUser?.allow_mutual_unlock === false;
                const disabledByOther = otherUser?.allow_mutual_unlock === false;

                return {
                    icon: <Lock className="w-5 h-5 text-muted-foreground" />,
                    title: "WhatsApp Unlock Not Available",
                    description: missingMessages ? "Both users need to send at least one message first" :
                                missingNumbers ? "Both users need to add their phone numbers" :
                                disabledByUser ? "You have disabled mutual unlocks in your profile" :
                                disabledByOther ? `${otherUser.first_name || 'They'} have disabled mutual unlocks` :
                                "Requirements not met",
                    action: null,
                    variant: "muted"
                };

            case 'eligible':
                return {
                    icon: <Phone className="w-5 h-5 text-primary" />,
                    title: "Unlock WhatsApp Numbers",
                    description: `Exchange WhatsApp numbers with ${otherUser.first_name || 'them'}`,
                    action: (
                        <Button 
                            onClick={handleUnlockRequest}
                            disabled={isLoading}
                            className="bg-primary hover:bg-primary/90"
                        >
                            {isLoading ? "Sending..." : "Request Unlock"}
                        </Button>
                    ),
                    variant: "primary"
                };

            case 'waiting_for_other':
                return {
                    icon: <Clock className="w-5 h-5 text-amber-500" />,
                    title: "Waiting for Response",
                    description: `Waiting for ${otherUser.first_name || 'them'} to agree to unlock numbers`,
                    action: <Badge variant="outline" className="text-amber-600 border-amber-200">Pending</Badge>,
                    variant: "amber"
                };

            case 'other_waiting':
                return {
                    icon: <MessageSquare className="w-5 h-5 text-blue-500" />,
                    title: `${otherUser.first_name || 'They'} want to unlock numbers`,
                    description: "They've requested to exchange WhatsApp numbers with you",
                    action: (
                        <Button 
                            onClick={handleUnlockRequest}
                            disabled={isLoading}
                            className="bg-blue-600 hover:bg-blue-700"
                        >
                            {isLoading ? "Agreeing..." : "Agree to Unlock"}
                        </Button>
                    ),
                    variant: "blue"
                };

            case 'both_agreed':
                return {
                    icon: <Check className="w-5 h-5 text-green-500" />,
                    title: "Both Agreed - Unlocking Numbers",
                    description: "Processing unlock request...",
                    action: <Badge variant="outline" className="text-green-600 border-green-200">Processing</Badge>,
                    variant: "green"
                };

            case 'unlocked':
                const showCurrentUserNumber = currentUser?.show_number_after_unlock !== false;
                const showOtherUserNumber = otherUser?.show_number_after_unlock !== false;

                return {
                    icon: <Check className="w-5 h-5 text-green-500" />,
                    title: "Numbers Unlocked! 🎉",
                    description: "You can now contact each other on WhatsApp",
                    action: (
                        <div className="space-y-2">
                            {showOtherUserNumber && otherUser.phone_number && (
                                <div className="text-sm">
                                    <span className="font-medium">{otherUser.first_name || 'Their'} WhatsApp:</span>
                                    <a 
                                        href={`https://wa.me/${otherUser.phone_number.replace(/\D/g, '')}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="ml-2 text-primary hover:underline font-mono"
                                    >
                                        {otherUser.phone_number}
                                    </a>
                                </div>
                            )}
                            {showCurrentUserNumber && currentUser.phone_number && (
                                <div className="text-sm text-muted-foreground">
                                    <span className="font-medium">Your WhatsApp:</span>
                                    <span className="ml-2 font-mono">{currentUser.phone_number}</span>
                                </div>
                            )}
                        </div>
                    ),
                    variant: "green"
                };

            default:
                return null;
        }
    };

    const statusContent = getStatusContent();
    if (!statusContent) return null;

    const getCardClassName = () => {
        const baseClasses = "mb-4 border-l-4 shadow-sm";
        switch (statusContent.variant) {
            case 'primary':
                return `${baseClasses} border-l-primary bg-primary/5`;
            case 'amber':
                return `${baseClasses} border-l-amber-500 bg-amber-50`;
            case 'blue':
                return `${baseClasses} border-l-blue-500 bg-blue-50`;
            case 'green':
                return `${baseClasses} border-l-green-500 bg-green-50`;
            case 'muted':
            default:
                return `${baseClasses} border-l-muted-foreground bg-muted/20`;
        }
    };

    return (
        <AnimatePresence>
            <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
            >
                <Card className={getCardClassName()}>
                    <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                            <div className="mt-1">
                                {statusContent.icon}
                            </div>
                            <div className="flex-1 min-w-0">
                                <h3 className="font-semibold text-foreground mb-1">
                                    {statusContent.title}
                                </h3>
                                <p className="text-sm text-muted-foreground mb-3">
                                    {statusContent.description}
                                </p>
                                {statusContent.action && (
                                    <div className="flex items-center gap-2">
                                        {statusContent.action}
                                    </div>
                                )}
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </motion.div>
        </AnimatePresence>
    );
};

export default UnlockBanner;
