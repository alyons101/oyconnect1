import React, { useState, useRef, useEffect } from 'react';

const OptimizedImage = ({ src, alt, className, style, onLoad, priority = false }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [currentSrc, setCurrentSrc] = useState(null);
  const imgRef = useRef(null);
  const observerRef = useRef(null);

  // Aggressive image optimization
  const getUltraOptimizedUrl = (url, width = 400, height = 500) => {
    if (!url) return null;
    
    // Unsplash - ultra optimized
    if (url.includes('unsplash.com')) {
      return `${url}&w=${width}&h=${height}&fit=crop&crop=face,entropy&auto=format&q=60&fm=webp&dpr=1`;
    }
    
    // Supabase Storage - ultra optimized
    if (url.includes('supabase.co/storage/')) {
      const baseUrl = url.split('?')[0];
      return `${baseUrl}?width=${width}&height=${height}&resize=cover&quality=60&format=webp`;
    }
    
    // Generic optimization
    if (url.includes('http')) {
      return `${url}${url.includes('?') ? '&' : '?'}w=${width}&h=${height}&q=60&fm=webp&fit=crop`;
    }
    
    return url;
  };

  // Get size based on className
  const getSizeConfig = () => {
    if (className?.includes('h-96')) return { width: 384, height: 384 };
    if (className?.includes('h-48')) return { width: 384, height: 192 };
    if (className?.includes('h-32')) return { width: 128, height: 128 };
    if (className?.includes('h-24')) return { width: 96, height: 96 };
    if (className?.includes('h-16')) return { width: 64, height: 64 };
    if (className?.includes('h-14')) return { width: 56, height: 56 };
    if (className?.includes('h-12')) return { width: 48, height: 48 };
    if (className?.includes('h-10')) return { width: 40, height: 40 };
    if (className?.includes('aspect-[4/5]')) return { width: 320, height: 400 };
    if (className?.includes('aspect-square')) return { width: 300, height: 300 };
    return { width: 320, height: 400 }; // Smaller default
  };

  const sizeConfig = getSizeConfig();
  const optimizedSrc = getUltraOptimizedUrl(src, sizeConfig.width, sizeConfig.height);

  // Intersection Observer for lazy loading
  useEffect(() => {
    if (priority || !imgRef.current) return;

    observerRef.current = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setCurrentSrc(optimizedSrc);
          observerRef.current?.disconnect();
        }
      },
      {
        rootMargin: '50px', // Load 50px before entering viewport
        threshold: 0.1
      }
    );

    observerRef.current.observe(imgRef.current);

    return () => observerRef.current?.disconnect();
  }, [optimizedSrc, priority]);

  // Load immediately if priority
  useEffect(() => {
    if (priority) {
      setCurrentSrc(optimizedSrc);
    }
  }, [optimizedSrc, priority]);

  const handleLoad = () => {
    setIsLoaded(true);
    onLoad?.();
  };

  const handleError = () => {
    setHasError(true);
    // Fallback to a smaller, guaranteed-to-load image
    const fallback = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIGZpbGw9IiNkZGQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTIgMmM1LjUxNCAwIDEwIDQuNDg2IDEwIDEwcy00LjQ4NiAxMC0xMCAxMFMyIDEyIDIgMTIgNi40ODYgMiAxMiAyem0wIDJDNy41ODkgNCA0IDcuNTg5IDQgMTJzMy41ODkgOCA4IDggOC0zLjU4OSA4LTgtMy41ODktOC04LTh6bTAgM2MxLjY1NyAwIDMgMS4zNDMgMyAzcy0xLjM0MyAzLTMgMy0zLTEuMzQzLTMtMyAxLjM0My0zIDMtM3ptMCA2YzMuMzEzIDAgNiAyLjY4NyA2IDZ2MUg2di0xYzAtMy4zMTMgMi42ODctNiA2LTZ6Ii8+PC9zdmc+';
    setCurrentSrc(fallback);
  };

  return (
    <div ref={imgRef} className={`relative overflow-hidden ${className}`} style={style}>
      {/* Ultra-fast loading placeholder */}
      {!isLoaded && (
        <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-50 dark:from-gray-800 dark:to-gray-900">
          <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent animate-pulse" />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-8 h-8 bg-primary/10 rounded-full animate-pulse" />
          </div>
        </div>
      )}
      
      {/* Error state */}
      {hasError && !currentSrc?.includes('data:image') && (
        <div className="absolute inset-0 bg-gradient-to-br from-gray-100 to-gray-50 dark:from-gray-800 dark:to-gray-900 flex items-center justify-center">
          <div className="text-center text-muted-foreground">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-1">
              <span className="text-xs font-bold">{alt?.[0]?.toUpperCase() || '?'}</span>
            </div>
            <span className="text-xs">Photo</span>
          </div>
        </div>
      )}
      
      {/* Optimized image */}
      {currentSrc && (
        <img
          src={currentSrc}
          alt={alt}
          className={`w-full h-full object-cover transition-opacity duration-200 ${
            isLoaded ? 'opacity-100' : 'opacity-0'
          }`}
          loading={priority ? 'eager' : 'lazy'}
          decoding="async"
          onLoad={handleLoad}
          onError={handleError}
          style={{
            ...style,
            objectPosition: style?.objectPosition || 'center center',
            willChange: 'opacity'
          }}
        />
      )}
    </div>
  );
};

export default OptimizedImage;