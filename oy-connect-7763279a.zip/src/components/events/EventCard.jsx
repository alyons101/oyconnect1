import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Users } from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";

export default function EventCard({ event }) {
  const imageUrl = event.image_url || `https://source.unsplash.com/random/400x300?event&sig=${event.id}`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="overflow-hidden h-full flex flex-col">
        <img
          src={imageUrl}
          alt={event.title}
          className="w-full h-48 object-cover"
        />

        <CardHeader>
          <CardTitle className="text-lg font-bold">{event.title}</CardTitle>
          <p className="text-sm text-muted-foreground">by {event.organizer}</p>
        </CardHeader>

        <CardContent className="flex-grow space-y-3">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="w-4 h-4" />
            <span>{format(new Date(event.date), "E, MMM d 'at' h:mm a")}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="w-4 h-4" />
            <span>{event.location}</span>
          </div>
           <p className="text-sm text-foreground/80 line-clamp-3 pt-2">
            {event.description}
          </p>
        </CardContent>
        <CardFooter>
            <Button className="w-full">View Details</Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}