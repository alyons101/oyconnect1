import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ArrowRight, Share, Check, Home, MessageSquare, Calendar, PlusSquare } from 'lucide-react';

const IosInstruction = ({ icon, text }) => (
  <div className="flex items-center gap-4 text-left">
    <div className="p-2 bg-secondary rounded-lg">{icon}</div>
    <span className="font-medium text-foreground">{text}</span>
  </div>
);

export default function FirstTimeUserTour({ onFinish }) {
  const [step, setStep] = useState(1);
  const [isIos, setIsIos] = useState(false);

  useEffect(() => {
    const isAppleDevice = /iPhone|iPad|iPod/.test(navigator.userAgent);
    setIsIos(isAppleDevice);
  }, []);

  const totalSteps = isIos ? 5 : 4;

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(s => s + 1);
    } else {
      handleFinish();
    }
  };
  
  const handleFinish = () => {
    localStorage.setItem('oyconnect_tour_completed', 'true');
    if (onFinish && typeof onFinish === 'function') {
      onFinish();
    }
  }
  
  const renderStepContent = () => {
    if (step === 1) {
      return {
        title: "Welcome to OyConnect 🎈",
        description: "You're in. This is your space to meet Jewish teens, find events, and vibe with people who get it.",
        content: null,
        buttonText: "Show Me Around",
        buttonIcon: <ArrowRight className="ml-2 w-4 h-4" />,
      };
    }
    if (step === 2) {
      return {
        title: "Your Dashboard 🗺️",
        description: "This is your dashboard — it shows people you might connect with, what's happening nearby, and any updates.",
        content: <Home className="w-16 h-16 text-primary" />,
        buttonText: "Next",
        buttonIcon: <ArrowRight className="ml-2 w-4 h-4" />,
      };
    }
    if (step === 3) {
      return {
        title: "Chat & Events 💬",
        description: "Wanna chat or check out what's going on? Tap the events tab or message people directly once you're connected.",
        content: <div className="flex gap-4"><MessageSquare className="w-16 h-16 text-primary" /><Calendar className="w-16 h-16 text-primary" /></div>,
        buttonText: "Next",
        buttonIcon: <ArrowRight className="ml-2 w-4 h-4" />,
      };
    }
    if (step === 4 && isIos) {
      return {
        title: "Use OyConnect like an app 🚀",
        description: "You're on Safari, so you can make OyConnect feel like a real app. Just follow these steps:",
        content: (
          <div className="space-y-4 my-4">
            <IosInstruction icon={<Share className="w-5 h-5 text-primary" />} text="Tap the Share icon at the bottom" />
            <IosInstruction icon={<PlusSquare className="w-5 h-5 text-primary" />} text="Scroll down and tap 'Add to Home Screen'" />
            <IosInstruction icon={<Check className="w-5 h-5 text-primary" />} text="Tap 'Add' in the top right" />
          </div>
        ),
        buttonText: "Got It",
        buttonIcon: <Check className="ml-2 w-4 h-4" />,
      };
    }
    return {
      title: "You're Ready ✅",
      description: "That's it — you're all set! Go explore, chat, or just scroll around.",
      content: <span className="text-5xl">🚀</span>,
      buttonText: "Take Me In",
      buttonIcon: null,
    };
  };

  const currentStep = renderStepContent();

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-start justify-center p-4 pt-20 safe-padding-top safe-padding-bottom">
      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.95 }}
          transition={{ duration: 0.3 }}
          className="w-full max-w-md mx-auto"
        >
          <Card className="text-center shadow-2xl border-border/50">
            <CardHeader>
              <CardTitle className="text-2xl font-bold">{currentStep.title}</CardTitle>
              <CardDescription className="text-md">{currentStep.description}</CardDescription>
            </CardHeader>
            <CardContent>
              {currentStep.content && <div className="flex items-center justify-center my-6">{currentStep.content}</div>}
              <Button onClick={handleNext} className="w-full mt-4" size="lg">
                {currentStep.buttonText}
                {currentStep.buttonIcon}
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}