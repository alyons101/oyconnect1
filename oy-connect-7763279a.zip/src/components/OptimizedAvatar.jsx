
import React, { useState, useRef, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const OptimizedAvatar = ({ src, alt, className, fallbackText, size = "default", priority = false }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [currentSrc, setCurrentSrc] = useState(null);
  const imgRef = useRef(null);

  const getUltraOptimizedUrl = (url) => {
    if (!url) return null;
    
    const dimensions = size === "large" ? { w: 96, h: 96 } : { w: 48, h: 48 };
    
    // Unsplash - ultra optimized for avatars
    if (url.includes('unsplash.com')) {
      return `${url}&w=${dimensions.w}&h=${dimensions.h}&fit=crop&crop=face&auto=format&q=65&fm=webp&dpr=1`;
    }
    
    // Supabase Storage - ultra optimized
    if (url.includes('supabase.co/storage/')) {
      const baseUrl = url.split('?')[0];
      return `${baseUrl}?width=${dimensions.w}&height=${dimensions.h}&resize=cover&quality=65&format=webp`;
    }
    
    // Generic optimization
    if (url.includes('http')) {
      return `${url}${url.includes('?') ? '&' : '?'}w=${dimensions.w}&h=${dimensions.h}&q=65&fm=webp&fit=crop`;
    }
    
    return url;
  };

  // Load immediately for avatars since they're usually small
  useEffect(() => {
    if (src) {
      setCurrentSrc(getUltraOptimizedUrl(src));
    }
  }, [src, size]);

  return (
    <Avatar className={className} ref={imgRef}>
      {!hasError && currentSrc && (
        <AvatarImage 
          src={currentSrc} 
          alt={alt}
          className={`object-cover transition-opacity duration-200 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
          loading={priority ? "eager" : "lazy"}
          decoding="async"
          onLoad={() => setIsLoaded(true)}
          onError={() => setHasError(true)}
          style={{ willChange: 'opacity' }}
        />
      )}
      <AvatarFallback className="bg-gradient-to-br from-primary/20 to-primary/10 text-primary font-semibold">
        {fallbackText || alt?.[0]?.toUpperCase() || '?'}
      </AvatarFallback>
    </Avatar>
  );
};

export default OptimizedAvatar;
