import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { RefreshCw, Users, UserPlus } from "lucide-react";

export default function EmptyState({ onRefresh }) {
  return (
    <Card className="h-full flex items-center justify-center border-0 shadow-xl bg-card rounded-2xl">
      <CardContent className="text-center p-8">
        <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
          <UserPlus className="w-12 h-12 text-primary" />
        </div>
        
        <h3 className="text-2xl font-bold text-foreground mb-3">
          No one else here yet!
        </h3>
        
        <p className="text-muted-foreground mb-6 max-w-sm">
          Invite your friends to join OyConnect so you can discover and connect with each other.
        </p>
        
        <div className="space-y-3">
          <Button
            onClick={onRefresh}
            variant="outline"
            className="px-6 py-3 rounded-xl font-medium flex items-center gap-2 mx-auto"
          >
            <RefreshCw className="w-5 h-5" />
            Check Again
          </Button>
          
          <p className="text-xs text-muted-foreground">
            Ask an admin to invite more users through the Workspace panel
          </p>
        </div>
      </CardContent>
    </Card>
  );
}