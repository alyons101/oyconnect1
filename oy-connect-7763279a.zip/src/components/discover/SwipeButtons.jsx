
import React from "react";
import { Button } from "@/components/ui/button";
import { X, MessageSquarePlus } from "lucide-react";
import { motion } from "framer-motion";

export default function SwipeButtons({ onSkip, onRequest, isMobile = false }) {
  const buttonSize = isMobile ? 'w-16 h-16' : 'w-20 h-20';
  const iconSize = isMobile ? 'w-6 h-6' : 'w-8 h-8';
  
  return (
    <div className={`flex justify-center ${isMobile ? 'gap-6' : 'gap-8'}`}>
      <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
        <Button
          onClick={onSkip}
          variant="outline"
          size="lg"
          className={`${buttonSize} rounded-full border-2 border-border bg-card shadow-md`}
        >
          <X className={`${iconSize} text-muted-foreground`} />
        </Button>
      </motion.div>

      <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
        <Button
          onClick={onRequest}
          size="lg"
          className={`${buttonSize} rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/30`}
        >
          <MessageSquarePlus className={iconSize} />
        </Button>
      </motion.div>
    </div>
  );
}
