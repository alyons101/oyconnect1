
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion, useMotionValue, useTransform } from "framer-motion";
import { MapPin, Sparkles } from "lucide-react";

const ProfileCard = ({ profile, onSwipeLeft, onSwipeRight, isMobile = false }) => {
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-25, 25]);

  const handleDragEnd = (event, info) => {
    const swipeThreshold = isMobile ? 80 : 100; // Lower threshold for mobile
    if (info.offset.x < -swipeThreshold) {
      onSwipeLeft();
    } else if (info.offset.x > swipeThreshold) {
      onSwipeRight();
    } else {
      x.set(0);
    }
  };

  return (
    <motion.div
      className="absolute inset-0"
      style={{ x, rotate }}
      drag="x"
      dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
      dragElastic={0.5}
      onDragEnd={handleDragEnd}
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={(direction) => ({
          x: direction > 0 ? 300 : -300,
          opacity: 0,
          scale: 0.8,
          transition: { duration: 0.3 }
      })}
    >
      <Card className="h-full w-full rounded-2xl overflow-hidden shadow-xl border-0 flex flex-col bg-card">
        <div className={`relative ${isMobile ? 'h-3/5' : 'h-3/5'}`}>
          <img
            src={profile.profile_photo}
            alt={profile.first_name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-0 left-0 p-4 text-white">
            <h2 className={`font-bold ${isMobile ? 'text-2xl' : 'text-3xl'}`}>
              {profile.first_name}, {profile.age}
            </h2>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              <span className={isMobile ? 'text-sm' : 'text-base'}>{profile.city}</span>
            </div>
          </div>
          {profile.verified &&
            <Badge variant="secondary" className="absolute top-4 right-4 bg-background text-primary font-semibold">
              <Sparkles className="w-4 h-4 mr-1"/>
              Verified
            </Badge>
          }
        </div>
        <CardContent className={`${isMobile ? 'p-3' : 'p-4'} flex-grow bg-card flex flex-col justify-around`}>
          <div>
            <h3 className={`font-semibold text-muted-foreground mb-2 ${isMobile ? 'text-sm' : 'text-base'}`}>Vibes</h3>
            <div className="flex flex-wrap gap-2">
              {profile.vibe_tags.map(tag => (
                <Badge key={tag} className={`bg-primary/10 text-primary-foreground font-medium ${isMobile ? 'text-xs' : 'text-sm'}`} variant="secondary">{tag}</Badge>
              ))}
            </div>
          </div>
          <div>
            <h3 className={`font-semibold text-muted-foreground mb-2 ${isMobile ? 'text-sm' : 'text-base'}`}>Interests</h3>
            <div className="flex flex-wrap gap-2">
              {profile.interest_tags.map(tag => (
                <Badge key={tag} variant="outline" className={`border-border text-foreground ${isMobile ? 'text-xs' : 'text-sm'}`}>{tag}</Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProfileCard;
