import { base44 } from './base44Client';


export const Message = base44.entities.Message;

export const Event = base44.entities.Event;

export const Connection = base44.entities.Connection;

export const DiscoveryProfile = base44.entities.DiscoveryProfile;



// auth sdk:
export const User = base44.auth;