import { base44 } from './base44Client';


export const getDiscoveryProfiles = base44.functions.getDiscoveryProfiles;

export const getDiscoverableUsers = base44.functions.getDiscoverableUsers;

