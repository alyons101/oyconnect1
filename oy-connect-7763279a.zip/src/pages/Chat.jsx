import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { User } from '@/api/entities';
import { Connection } from '@/api/entities';
import { Message } from '@/api/entities';
import { createPageUrl } from '@/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from "sonner";
import ChatHeader from '../components/chat/ChatHeader';
import ChatMessages from '../components/chat/ChatMessages';
import MessageInput from '../components/chat/MessageInput';
import UnlockBanner from '../components/chat/UnlockBanner';

const ChatSkeleton = () => (
    <div className="h-dvh flex flex-col">
        <header className="bg-card p-3 safe-padding-top border-b">
            <div className="flex items-center gap-3">
                <Skeleton className="w-10 h-10 rounded-full" />
                <div className="space-y-1">
                    <Skeleton className="h-5 w-24" />
                    <Skeleton className="h-3 w-16" />
                </div>
            </div>
        </header>
        <div className="flex-1 p-4 space-y-4">
            <div className="flex justify-start"><Skeleton className="h-10 w-2/3 rounded-lg" /></div>
            <div className="flex justify-end"><Skeleton className="h-16 w-1/2 rounded-lg" /></div>
            <div className="flex justify-start"><Skeleton className="h-8 w-1/3 rounded-lg" /></div>
        </div>
        <footer className="bg-card p-3 safe-padding-bottom border-t">
            <Skeleton className="h-12 w-full rounded-2xl" />
        </footer>
    </div>
);

// Safe user fetch function with error handling
const safeUserFetch = async (userId) => {
    if (!userId || typeof userId !== 'string' || userId.length < 10) {
        console.warn(`Invalid user ID: ${userId}`);
        return null;
    }
    
    try {
        const user = await User.get(userId);
        if (!user || !user.id) {
            console.warn(`User ${userId} not found or invalid`);
            return null;
        }
        return user;
    } catch (error) {
        console.warn(`Failed to fetch user ${userId}:`, error.message);
        return null;
    }
};

export default function ChatPage() {
    const [searchParams] = useSearchParams();
    const connectionId = searchParams.get('id');
    const navigate = useNavigate();

    const [messages, setMessages] = useState([]);
    const [connection, setConnection] = useState(null);
    const [otherUser, setOtherUser] = useState(null);
    const [currentUser, setCurrentUser] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [unlockStatus, setUnlockStatus] = useState('not_eligible');
    const [lastMessageId, setLastMessageId] = useState(null);

    const fetchChatData = useCallback(async () => {
        if (!connectionId) {
            navigate(createPageUrl('Chats'));
            return;
        }
        
        try {
            const user = await User.me();
            setCurrentUser(user);

            const conn = await Connection.get(connectionId);
            if (!conn || !conn.participants || !Array.isArray(conn.participants) || conn.participants.length !== 2) {
                throw new Error("Invalid connection data");
            }
            setConnection(conn);

            const otherUserId = conn.participants.find(p => p !== user.id);
            if (!otherUserId) {
                throw new Error("Other user not found in connection");
            }

            // Use safe user fetch
            const other = await safeUserFetch(otherUserId);
            if (!other) {
                toast.error("The other user in this chat no longer exists.");
                navigate(createPageUrl('Chats'));
                return;
            }
            
            setOtherUser(other);
            
            try {
                // OPTIMIZATION: Only load recent messages (last 50), not all messages
                const initialMessages = await Message.filter({ 
                    connection_id: connectionId 
                }, "created_date", 50);
                setMessages(initialMessages || []);
                
                // Track the most recent message ID for efficient polling
                if (initialMessages && initialMessages.length > 0) {
                    setLastMessageId(initialMessages[initialMessages.length - 1].id);
                }

                // Mark initial messages as read
                const unreadMessages = (initialMessages || []).filter(m => m.sender_id === otherUserId && !m.read);
                if (unreadMessages.length > 0) {
                    await Promise.all(unreadMessages.map(m => Message.update(m.id, { read: true }).catch(console.warn)));
                }
            } catch (messageError) {
                console.warn("Could not load messages:", messageError);
                setMessages([]);
            }

        } catch (error) {
            console.error("Error loading chat:", error);
            toast.error("Could not load chat.", { description: "This chat may no longer be available."});
            navigate(createPageUrl('Chats'));
        }
    }, [connectionId, navigate]);

    useEffect(() => {
        setIsLoading(true);
        fetchChatData().finally(() => setIsLoading(false));
    }, [fetchChatData]);
    
    // OPTIMIZATION: Much more efficient message polling - only check for new messages since last known message
    useEffect(() => {
        if (isLoading || !currentUser || !otherUser || !lastMessageId) return;

        const pollInterval = setInterval(async () => {
            if (document.visibilityState === 'visible') {
                try {
                    // Only fetch messages newer than the last known message
                    const newMessages = await Message.filter({ 
                        connection_id: connectionId,
                        created_date: { $gt: new Date(Date.now() - 30000).toISOString() }, // Last 30 seconds
                        sender_id: otherUser.id
                    }, "created_date");
                    
                    if (newMessages && newMessages.length > 0) {
                        setMessages(prev => {
                            const existingIds = new Set(prev.map(m => m.id));
                            const uniqueNew = newMessages.filter(nm => !existingIds.has(nm.id));
                            if (uniqueNew.length > 0) {
                                setLastMessageId(uniqueNew[uniqueNew.length - 1].id);
                                return [...prev, ...uniqueNew];
                            }
                            return prev;
                        });
                        
                        // Mark new messages as read
                        await Promise.all(newMessages.map(m => Message.update(m.id, { read: true }).catch(console.warn)));
                    }
                } catch (pollError) {
                    console.warn("Message polling error:", pollError);
                }
            }
        }, 10000); // OPTIMIZATION: Reduced polling frequency to 10 seconds
        
        return () => clearInterval(pollInterval);
    }, [connectionId, currentUser, otherUser, isLoading, lastMessageId]);

    const handleSendMessage = async (content) => {
        if (!currentUser || !connectionId || !connection) return;

        const tempId = `temp-${Date.now()}`;
        const newMessage = {
            id: tempId,
            connection_id: connectionId,
            sender_id: currentUser.id,
            content: content,
            read: false,
            created_date: new Date().toISOString(),
            participants: connection.participants,
        };
        
        setMessages(prev => [...prev, newMessage]);

        try {
            const createdMessage = await Message.create({
                connection_id: connectionId,
                sender_id: currentUser.id,
                content: content,
                participants: connection.participants,
            });

            if (!createdMessage || !createdMessage.id) {
                throw new Error("Message creation failed on the server.");
            }

            setMessages(prev => prev.map(m => m.id === tempId ? { ...m, ...createdMessage } : m));
            setLastMessageId(createdMessage.id); // Update last message ID
            await Connection.update(connectionId, { last_message_at: new Date().toISOString() }).catch(console.warn);
        } catch(error) {
            console.error("Failed to send message", error);
            toast.error("Message failed to send. Please try again.");
            setMessages(prev => prev.filter(m => m.id !== tempId));
        }
    };
    
    const handleBlock = async () => {
        if (!currentUser || !otherUser) return;
        try {
            await User.updateMyUserData({
                blocked_users: [...(currentUser.blocked_users || []), otherUser.id]
            });
            toast.success(`${otherUser.first_name} has been blocked.`, {
                description: "You will no longer see them or receive messages."
            });
            navigate(createPageUrl('Chats'));
        } catch (e) {
            toast.error("Failed to block user. Please try again.");
            console.error("Block error:", e);
        }
    };

    const handleUnlockStatusChange = (newStatus) => {
        setUnlockStatus(newStatus);
        // Refresh connection data to get updated unlock status
        if (newStatus === 'unlocked') {
            fetchChatData();
        }
    };

    if (isLoading) {
        return <ChatSkeleton />;
    }
    
    return (
        <div className="h-dvh flex flex-col bg-background">
            <ChatHeader otherUser={otherUser} onBlock={handleBlock} />
            
            <div className="flex-1 overflow-hidden flex flex-col">
                <div className="p-4 pb-0">
                    <UnlockBanner 
                        connection={connection}
                        currentUser={currentUser}
                        otherUser={otherUser}
                        onUnlockStatusChange={handleUnlockStatusChange}
                    />
                </div>
                
                <div className="flex-1 overflow-hidden">
                    <ChatMessages messages={messages} currentUser={currentUser} />
                </div>
            </div>
            
            <footer className="sticky bottom-0 mt-auto bg-card/80 backdrop-blur-md border-t border-border/50">
                <MessageInput onSendMessage={handleSendMessage} />
            </footer>
        </div>
    );
}