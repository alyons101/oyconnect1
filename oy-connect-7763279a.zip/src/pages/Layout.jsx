

import React, { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { Compass, MessageSquare, Calendar, User as UserIcon } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import NotificationManager from "./components/NotificationManager";

const navigationItems = [
  { title: "Discover", url: createPageUrl("DiscoverNew"), icon: Compass },
  { title: "Chats", url: createPageUrl("Chats"), icon: MessageSquare },
  { title: "Events", url: createPageUrl("Events"), icon: Calendar },
];

const profileNavItem = { title: "Profile", url: createPageUrl("Profile"), icon: UserIcon };

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [isReady, setIsReady] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);

    const storedTheme = localStorage.getItem('theme') || 'light';
    const root = window.document.documentElement;
    root.classList.remove('light', 'dark');
    root.classList.add(storedTheme);
    User.me().then(setCurrentUser).catch(() => setCurrentUser(null));

    return () => window.removeEventListener('resize', checkMobile);
  }, [location.pathname]);

  // This new useEffect will listen for changes from other pages (like Chats)
  // to update the unread count, without expensive background tasks.
  useEffect(() => {
    const handleStorageChange = () => {
      const count = localStorage.getItem('unreadCount') || '0';
      setUnreadCount(parseInt(count, 10));
    };

    // Set initial count
    handleStorageChange();

    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  useEffect(() => {
    const checkOnboarding = async () => {
      const noLayoutPages = ['Onboarding', 'AuthError', 'Chat'];
      if (noLayoutPages.includes(currentPageName)) {
        setIsReady(true);
        return;
      }
      try {
        const user = await User.me();
        if (!user.onboarding_complete) {
          navigate(createPageUrl('Onboarding'));
        } else {
          setIsReady(true);
        }
      } catch (error) {
        console.error("Authentication check failed:", error);
        navigate(createPageUrl('AuthError'));
      }
    };
    checkOnboarding();
  }, [currentPageName, navigate]);

  // Function to capitalize first letter of each name
  const formatName = (name) => {
    if (!name) return '';
    return name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
  };

  const GlobalStyles = () => (
     <style>{`
        :root {
          --oy-orange-hsl: 28 100% 50%;
          --background: 210 16% 98%;
          --foreground: 210 10% 23%;
          --card: 0 0% 100%;
          --card-foreground: 210 10% 23%;
          --popover: 0 0% 100%;
          --popover-foreground: 210 10% 23%;
          --primary: var(--oy-orange-hsl);
          --primary-foreground: 0 0% 100%;
          --secondary: 210 14% 89%;
          --secondary-foreground: 210 10% 23%;
          --muted: 210 14% 93%;
          --muted-foreground: 210 9% 45%;
          --accent: 210 14% 95%;
          --accent-foreground: 210 10% 23%;
          --destructive: 0 84.2% 60.2%;
          --destructive-foreground: 0 0% 100%;
          --border: 210 14% 89%;
          --input: 210 14% 89%;
          --ring: var(--oy-orange-hsl);
          --radius: 0.75rem;
        }
        .dark {
          --background: 220 13% 8%;
          --foreground: 0 0% 98%;
          --card: 220 13% 12%;
          --card-foreground: 0 0% 98%;
          --popover: 220 13% 12%;
          --popover-foreground: 0 0% 98%;
          --primary: var(--oy-orange-hsl);
          --primary-foreground: 0 0% 100%;
          --secondary: 210 4% 18%;
          --secondary-foreground: 0 0% 98%;
          --muted: 210 4% 15%;
          --muted-foreground: 210 8% 65%;
          --accent: 210 4% 16%;
          --accent-foreground: 0 0% 98%;
          --destructive: 0 62.8% 30.6%;
          --destructive-foreground: 0 0% 100%;
          --border: 210 4% 18%;
          --input: 210 4% 18%;
          --ring: var(--oy-orange-hsl);
        }

        * {
          box-sizing: border-box;
          -webkit-tap-highlight-color: transparent; /* Disable tap highlight on iOS */
        }

        html {
          scroll-behavior: smooth;
          -webkit-text-size-adjust: 100%; /* Prevent font scaling in landscape */
        }

        body {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
          -webkit-overflow-scrolling: touch; /* Enable momentum scrolling */
          overscroll-behavior: contain; /* Prevent pull-to-refresh on body */
          -webkit-tap-highlight-color: transparent;
          font-size: 16px;
          line-height: 1.6;
          font-weight: 400;
          transition: background-color 0.3s ease, color 0.3s ease;
          overflow-x: hidden; /* Prevent horizontal scrolling */
          width: 100%;
        }

        /* Ultra-fast image loading optimizations */
        img {
          image-rendering: -webkit-optimize-contrast;
          image-rendering: optimizeSpeed;
          image-rendering: optimize-contrast;
          image-rendering: crisp-edges;
          transform: translateZ(0);
          backface-visibility: hidden;
          will-change: opacity;
        }

        /* Preload critical images */
        .preload-image {
          content: '';
          position: absolute;
          left: -9999px;
          top: -9999px;
          width: 1px;
          height: 1px;
        }

        /* Optimized animations */
        @keyframes ultraFastShimmer {
          0% { transform: translateX(-100%); opacity: 0.3; }
          50% { opacity: 0.5; }
          100% { transform: translateX(100%); opacity: 0.3; }
        }

        .shimmer {
          background: linear-gradient(90deg,
            transparent 0%,
            rgba(255,255,255,0.4) 50%,
            transparent 100%
          );
          background-size: 200% 100%;
          animation: ultraFastShimmer 1s infinite;
          will-change: transform, opacity;
        }

        /* Mobile optimizations */
        @media (max-width: 768px) {
          body {
            font-size: 14px;
            line-height: 1.5;
          }

          /* Reduce image quality on mobile for speed */
          img {
            image-rendering: optimizeSpeed;
          }

          .container {
            padding-left: 1rem;
            padding-right: 1rem;
          }

          /* Improve touch targets */
          button, a, [role="button"] {
            min-height: 44px;
            min-width: 44px;
          }

          /* Better scrolling */
          .scroll-container {
            -webkit-overflow-scrolling: touch;
            scroll-behavior: smooth;
            overscroll-behavior-y: auto; /* Allow vertical scroll but contain it */
          }
          
          /* Fix login page sizing on mobile */
          .auth-container, [class*="auth"], [id*="auth"],
          .login-container, [class*="login"], [id*="login"],
          .signup-container, [class*="signup"], [id*="signup"] {
            width: 100% !important;
            max-width: 400px !important;
            margin: 0 auto !important;
            padding: 20px !important;
            min-height: auto !important;
          }

          /* Ensure login forms are properly sized */
          form[class*="auth"], form[class*="login"], form[class*="signup"] {
            width: 100% !important;
            max-width: none !important;
          }

          /* Fix input sizing in auth forms */
          .auth-container input, .login-container input, .signup-container input,
          [class*="auth"] input, [class*="login"] input, [class*="signup"] input {
            width: 100% !important;
            font-size: 16px !important;
            padding: 12px !important;
            box-sizing: border-box !important;
          }

          /* Fix button sizing in auth forms */
          .auth-container button, .login-container button, .signup-container button,
          [class*="auth"] button, [class*="login"] button, [class*="signup"] button {
            width: 100% !important;
            font-size: 16px !important;
            padding: 12px !important;
            min-height: 48px !important;
          }
        }

        /* Tablet optimizations */
        @media (min-width: 769px) and (max-width: 1024px) {
          body {
            font-size: 15px;
            line-height: 1.55;
          }
        }

        /* Desktop optimizations */
        @media (min-width: 1025px) {
          body {
            font-size: 16px;
            line-height: 1.6;
          }

          /* Hover effects for desktop */
          .hover-lift:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
          }
        }

        /* iPhone specific optimizations */
        @supports (-webkit-touch-callout: none) {
          body {
            /* Disable selection on non-text elements */
            -webkit-user-select: none;
            user-select: none;
          }

          input, textarea, [contenteditable] {
            /* Allow selection on form elements */
            -webkit-user-select: auto;
            user-select: auto;
          }

          /* Fix iOS zoom on input focus by ensuring font size is 16px */
          input[type="text"], input[type="email"], input[type="password"],
          input[type="search"], input[type="tel"], input[type="url"],
          input[type="number"], input[type="date"], textarea, select {
            font-size: 16px !important;
          }
        }

        /* Enhanced safe areas for notched iPhones */
        .safe-padding-top { padding-top: max(env(safe-area-inset-top), 1rem); }
        .safe-padding-bottom { padding-bottom: max(env(safe-area-inset-bottom), 1rem); }
        .safe-padding-left { padding-left: max(env(safe-area-inset-left), 1rem); }
        .safe-padding-right { padding-right: max(env(safe-area-inset-right), 1rem); }

        /* Backdrop blur fallback */
        .backdrop-blur-md {
          backdrop-filter: blur(12px);
          -webkit-backdrop-filter: blur(12px);
        }

        /* Enhanced gradients */
        .gradient-primary {
          background: linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--primary) / 0.8) 100%);
        }

        .gradient-card {
          background: linear-gradient(135deg, hsl(var(--card)) 0%, hsl(var(--card) / 0.95) 100%);
        }

        /* Enhanced shadows */
        .shadow-elegant {
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08), 0 2px 8px rgba(0, 0, 0, 0.06);
        }

        .shadow-floating {
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12), 0 4px 16px rgba(0, 0, 0, 0.08);
        }

        /* Ultra-smooth page transitions */
        .page-enter {
          opacity: 0;
          transform: translateY(10px);
        }

        .page-enter-active {
          opacity: 1;
          transform: translateY(0);
          transition: opacity 0.2s ease, transform 0.2s ease;
        }

        .page-exit {
          opacity: 1;
          transform: translateY(0);
        }

        .page-exit-active {
          opacity: 0;
          transform: translateY(-10px);
          transition: opacity 0.2s ease, transform 0.2s ease;
        }

        /* Critical resource hints */
        .dns-prefetch { display: none; }
      `}</style>
  );

  if (!isReady) {
    return (
        <div className="min-h-screen w-full flex items-center justify-center bg-background">
            <GlobalStyles />
            <div className="flex flex-col items-center space-y-4">
                <div className="bg-orange-300 w-16 h-16 from-primary to-primary/80 rounded-2xl flex items-center justify-center shadow-floating">
                     <span className="text-xl font-bold text-primary-foreground">Oy</span>
                </div>
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-primary border-t-transparent"></div>
            </div>
        </div>
    );
  }

  const noLayoutPages = ['Onboarding', 'AuthError', 'Chat'];
  if (noLayoutPages.includes(currentPageName)) {
    return (
        <>
            <GlobalStyles />
            <NotificationManager />
            {children}
        </>
    );
  }

  const allNavItems = currentUser ? [...navigationItems, profileNavItem] : navigationItems;

  return (
    <div className="h-dvh flex flex-col bg-background font-sans">
      <GlobalStyles />
      {/* The NotificationManager is now much lighter and doesn't set the count */}
      <NotificationManager />

      <header className="bg-white/95 backdrop-blur-md border-b border-border/50 sticky top-0 z-50 safe-padding-top shadow-elegant">
        <div className="max-w-6xl mx-auto px-4 py-2 safe-padding-left safe-padding-right">
          <div className="flex items-center justify-between">
            <Link to={createPageUrl('DiscoverNew')} className="flex items-center space-x-3 hover-lift">
               <div className="bg-orange-300 text-white text-lg font-bold w-10 h-10 from-primary to-primary/80 rounded-xl flex items-center justify-center shadow-lg">
                Oy
              </div>
              <h1 className={`font-bold bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent ${isMobile ? 'text-xl' : 'text-2xl'}`}>OyConnect</h1>
            </Link>
            <nav className="hidden md:flex items-center space-x-1">
              {navigationItems.map((item) => (
                <Link
                  key={item.title}
                  to={item.url}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-xl transition-all duration-200 text-sm font-semibold relative hover-lift ${
                    location.pathname === item.url
                      ? "bg-gradient-to-r from-primary/10 to-primary/5 text-primary shadow-elegant"
                      : "text-muted-foreground hover:text-primary hover:bg-accent/50"
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span>{item.title}</span>
                  {item.title === "Chats" && unreadCount > 0 && (
                    <div className="absolute -top-1 -right-1 bg-gradient-to-br from-red-500 to-red-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold shadow-lg animate-pulse">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </div>
                  )}
                </Link>
              ))}
              {currentUser && (
                <Link
                  to={profileNavItem.url}
                  className={`flex items-center space-x-3 pl-3 pr-4 py-2 rounded-xl transition-all duration-200 text-sm font-semibold hover-lift ${
                    location.pathname === profileNavItem.url
                      ? "bg-gradient-to-r from-primary/10 to-primary/5 text-primary shadow-elegant"
                      : "text-muted-foreground hover:text-primary hover:bg-accent/50"
                  }`}
                >
                  <Avatar className="w-8 h-8 ring-2 ring-primary/20">
                    <AvatarImage src={currentUser.profile_photo} alt={formatName(currentUser.first_name)} className="object-cover" />
                    <AvatarFallback className="bg-gradient-to-br from-primary/20 to-primary/10 text-primary font-semibold">
                      {`${formatName(currentUser.first_name)?.[0] || ''}${formatName(currentUser.last_name)?.[0] || ''}`}
                    </AvatarFallback>
                  </Avatar>
                  <span className="font-semibold">{formatName(currentUser.first_name)}</span>
                </Link>
              )}
            </nav>
          </div>
        </div>
      </header>

      <main className={`flex-1 overflow-y-auto ${isMobile ? 'pb-24' : 'pb-8'} safe-padding-left safe-padding-right scroll-container`}>
        <div className="page-enter page-enter-active">
          {children}
        </div>
      </main>

      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-border/50 z-50 safe-padding-bottom shadow-floating">
        <div className="flex items-center justify-around py-2 px-2 safe-padding-left safe-padding-right">
          {allNavItems.map((item) => (
            <Link
              key={item.title}
              to={item.url}
              className={`flex flex-col items-center space-y-1 p-3 rounded-xl transition-all duration-200 flex-1 relative ${
                location.pathname === item.url
                  ? "text-primary bg-gradient-to-br from-primary/10 to-primary/5 shadow-elegant"
                  : "text-muted-foreground active:bg-accent/30"
              }`}
            >
              <item.icon className="w-6 h-6" />
              <span className="text-xs font-medium">{item.title}</span>
              {item.title === "Chats" && unreadCount > 0 && (
                <div className="absolute top-2 right-3 bg-gradient-to-br from-red-500 to-red-600 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center font-bold shadow-lg animate-pulse">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </div>
              )}
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}

