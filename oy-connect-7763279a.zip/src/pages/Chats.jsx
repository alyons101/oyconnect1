import React, { useState, useEffect, useCallback } from "react";
import { Connection } from "@/api/entities";
import { Message } from "@/api/entities";
import { User } from "@/api/entities";
import { MessageSquare, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { motion } from "framer-motion";
import OptimizedAvatar from '../components/OptimizedAvatar';

const EmptyChats = () => (
    <div className="text-center mt-20">
        <Users className="mx-auto h-16 w-16 text-muted-foreground/50" />
        <h3 className="mt-4 text-xl font-semibold text-foreground">No connections yet</h3>
        <p className="mt-1 text-muted-foreground">Start requesting chats in the Discover tab!</p>
    </div>
);

const formatLastMessageTime = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now - date) / (1000 * 60 * 60);
    
    if (diffInHours < 24) {
      return format(date, 'HH:mm');
    } else if (diffInHours < 168) {
      return format(date, 'EEE');
    } else {
      return format(date, 'MMM d');
    }
};

const getLastMessagePreview = (message, currentUserId) => {
    if (!message) return "Say hi!";
    
    const isFromMe = message.sender_id === currentUserId;
    const prefix = isFromMe ? "You: " : "";
    const content = message.content.length > 30 
      ? message.content.substring(0, 30) + "..." 
      : message.content;
    
    return prefix + content;
};

export default function ChatsPage() {
  const [connections, setConnections] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);

  const fetchConnections = useCallback(async () => {
    setIsLoading(true);
    try {
        const user = await User.me();
        setCurrentUser(user);

        // Get all connections for this user
        const userConnections = await Connection.filter(
            { participants: user.id },
            "-last_message_at"
        );

        if (!userConnections || userConnections.length === 0) {
            setConnections([]);
            setIsLoading(false);
            return;
        }

        // ENHANCED FIX: More robust deduplication
        const uniqueConnectionsMap = new Map();
        userConnections.forEach(conn => {
            if (!conn || !Array.isArray(conn.participants) || conn.participants.length !== 2) {
                return; // Skip invalid connections
            }
            
            const otherUserId = conn.participants.find(id => id !== user.id);
            if (!otherUserId) {
                return; // Skip connections without valid other user
            }
            
            // Use a consistent key for deduplication
            const connectionKey = [user.id, otherUserId].sort().join('_');
            
            // Only keep the most recent connection (by last_message_at or created_date)
            if (!uniqueConnectionsMap.has(connectionKey)) {
                uniqueConnectionsMap.set(connectionKey, conn);
            } else {
                const existing = uniqueConnectionsMap.get(connectionKey);
                const currentTime = new Date(conn.last_message_at || conn.created_date || 0);
                const existingTime = new Date(existing.last_message_at || existing.created_date || 0);
                
                if (currentTime > existingTime) {
                    uniqueConnectionsMap.set(connectionKey, conn);
                }
            }
        });
        
        const uniqueConnections = Array.from(uniqueConnectionsMap.values());

        if (uniqueConnections.length === 0) {
            setConnections([]);
            setIsLoading(false);
            return;
        }

        // OPTIMIZATION: Get all unique user IDs first
        const allUserIds = [...new Set(uniqueConnections.flatMap(conn => conn.participants))];
        const otherUserIds = allUserIds.filter(id => id !== user.id);

        // OPTIMIZATION: Try to batch fetch users (if supported by the API)
        const allUsers = {};
        
        // For now, we'll still need individual fetches, but we'll do them concurrently
        const userFetchPromises = otherUserIds.map(async (userId) => {
            try {
                const userData = await User.get(userId);
                if (userData && userData.id) {
                    allUsers[userId] = userData;
                }
            } catch (userError) {
                console.warn(`Could not fetch user ${userId}:`, userError.message);
                // Create a fallback user object so the chat still appears
                allUsers[userId] = {
                    id: userId,
                    first_name: "User",
                    profile_photo: null
                };
            }
        });

        // Wait for all user fetches to complete
        await Promise.all(userFetchPromises);

        // OPTIMIZATION: Get only the most recent message for each connection, not all messages
        const connectionIds = uniqueConnections.map(conn => conn.id);
        let recentMessages = [];
        try {
            // Get only the most recent message for each connection
            for (const connId of connectionIds) {
                try {
                    const msgs = await Message.filter({ connection_id: connId }, "-created_date", 1);
                    if (msgs && msgs.length > 0) {
                        recentMessages.push(msgs[0]);
                    }
                } catch (msgError) {
                    console.warn(`Could not fetch messages for connection ${connId}`);
                }
            }
        } catch (messageError) {
            console.warn("Could not load messages:", messageError);
            recentMessages = [];
        }

        // Group messages by connection
        const messagesByConnection = {};
        recentMessages.forEach(msg => {
            messagesByConnection[msg.connection_id] = msg;
        });

        // Build connections with details using uniqueConnections
        const connectionsWithDetails = uniqueConnections.map(conn => {
            const otherUserId = conn.participants.find(id => id !== user.id);
            const otherUser = allUsers[otherUserId];
            
            if (!otherUser) {
                return null;
            }

            const lastMessage = messagesByConnection[conn.id] || null;
            
            // OPTIMIZATION: Calculate unread count only for recent messages, not all messages
            const unreadCount = lastMessage && lastMessage.sender_id === otherUserId && !lastMessage.read ? 1 : 0;

            return { ...conn, otherUser, lastMessage, unreadCount };
        }).filter(Boolean);

        setConnections(connectionsWithDetails);

        // Calculate and store total unread count
        const totalUnread = connectionsWithDetails.reduce((sum, conn) => sum + (conn.unreadCount || 0), 0);
        localStorage.setItem('unreadCount', totalUnread.toString());
        window.dispatchEvent(new Event('storage'));

    } catch (error) {
        console.error("Error fetching connections:", error);
        setConnections([]);
    } finally {
        setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchConnections();
  }, [fetchConnections]);

  return (
    <div className="max-w-2xl mx-auto p-4">
      <motion.div 
        className="flex items-center gap-3 mb-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="p-2 bg-gradient-to-br from-primary/20 to-primary/10 rounded-xl">
          <MessageSquare className="w-6 h-6 text-primary"/>
        </div>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">Chats</h1>
      </motion.div>
      
      {isLoading ? (
        <div className="space-y-3">
            {[...Array(3)].map((_, i) => (
                <motion.div 
                  key={i} 
                  className="flex items-center space-x-4 p-4"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                >
                    <Skeleton className="h-14 w-14 rounded-full shimmer" />
                    <div className="space-y-2 flex-1">
                        <Skeleton className="h-4 w-[250px] shimmer" />
                        <Skeleton className="h-4 w-[200px] shimmer" />
                    </div>
                    <Skeleton className="h-4 w-12 shimmer" />
                </motion.div>
            ))}
        </div>
      ) : (
        <div className="space-y-2">
          {connections.length > 0 ? (
            connections.map((conn, index) => (
            <motion.div
              key={`${conn.id}-${conn.otherUser?.id}`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Link to={createPageUrl(`Chat?id=${conn.id}`)}>
                <Card className="hover:bg-accent/50 transition-all duration-200 p-4 border-border/50 hover:border-primary/20 hover:shadow-elegant hover-lift">
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <OptimizedAvatar
                        src={conn.otherUser?.profile_photo}
                        alt={conn.otherUser?.first_name || 'User'}
                        fallbackText={conn.otherUser?.first_name?.[0] || 'U'}
                        className="h-14 w-14 ring-2 ring-primary/10"
                      />
                      {conn.unreadCount > 0 && (
                        <div className="absolute -top-1 -right-1 bg-gradient-to-br from-red-500 to-red-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-bold shadow-lg animate-pulse">
                          {conn.unreadCount > 9 ? '9+' : conn.unreadCount}
                        </div>
                      )}
                    </div>
                    <div className="flex-grow min-w-0">
                      <div className="flex items-center justify-between">
                        <h3 className={`text-lg truncate ${conn.unreadCount > 0 ? 'font-bold text-foreground' : 'font-semibold text-foreground'}`}>
                          {conn.otherUser?.first_name || 'User'}
                        </h3>
                        {conn.lastMessage && (
                          <span className="text-xs text-muted-foreground ml-2 flex-shrink-0">
                            {formatLastMessageTime(conn.lastMessage.created_date)}
                          </span>
                        )}
                      </div>
                      <p className={`text-sm truncate ${conn.unreadCount > 0 ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>
                        {getLastMessagePreview(conn.lastMessage, currentUser?.id)}
                      </p>
                    </div>
                  </div>
                </Card>
              </Link>
            </motion.div>
          ))
        ) : (
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-8"
              >
              <EmptyChats/>
            </motion.div>
        )}
        </div>
      )}
    </div>
  );
}