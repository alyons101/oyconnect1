
import React, { useState, useEffect, useRef } from 'react';
import { User } from '@/api/entities';
import { DiscoveryProfile } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import OptimizedAvatar from '../components/OptimizedAvatar';
import { Edit, LogOut, ChevronRight, Bell, Camera, CheckCircle2, XCircle, ShieldCheck, Trash2, SearchCheck, Phone } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { UploadFile } from '@/api/integrations';
import { toast } from "sonner";
import { motion } from 'framer-motion';
import { Switch } from "@/components/ui/switch";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const SettingsRow = ({ icon, title, subtitle, onClick, children }) => (
  <div
    className="flex items-center p-4 transition-colors hover:bg-accent rounded-lg cursor-pointer"
    onClick={onClick}
  >
    <div className="flex items-center gap-4">
      <div className="p-2 bg-secondary rounded-lg">{icon}</div>
      <div>
        <h3 className="font-semibold text-foreground">{title}</h3>
        {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
      </div>
    </div>
    <div className="ml-auto">{children || <ChevronRight className="w-5 h-5 text-muted-foreground" />}</div>
  </div>
);

export default function ProfilePage() {
  const [user, setUser] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [notificationPermission, setNotificationPermission] = useState('default');
  const [isMobile, setIsMobile] = useState(false);
  const navigate = useNavigate();
  const fileInputRef = useRef(null);

  useEffect(() => {
    User.me().then(setUser).catch(() => navigate(createPageUrl('DiscoverNew')));
    
    // Check if device is mobile
    setIsMobile(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent));
    
    if ('Notification' in window) {
      setNotificationPermission(Notification.permission);
    }
  }, [navigate]);

  // Function to capitalize first letter of each name
  const formatName = (name) => {
    if (!name) return '';
    return name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
  };

  const handleLogout = async () => {
    await User.logout();
    navigate(createPageUrl('DiscoverNew'));
  };

  const handleDeleteProfile = async () => {
    if (!user) return;
    try {
        // Also delete the public discovery profile
        const existingProfiles = await DiscoveryProfile.filter({ user_id: user.id });
        if (existingProfiles.length > 0) {
            await DiscoveryProfile.delete(existingProfiles[0].id);
        }

        await User.delete(user.id);
        toast.success("Your profile has been deleted.");
        await User.logout();
        navigate(createPageUrl('DiscoverNew'));
    } catch (error) {
        console.error("Failed to delete profile:", error);
        toast.error("Failed to delete profile. Please try again or contact support.");
    }
  };

  const handleAvatarClick = () => {
    if (!isUploading) {
      fileInputRef.current.click();
    }
  };

  const handlePhotoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const { file_url } = await UploadFile({ file });
      const updatedUser = await User.updateMyUserData({ profile_photo: file_url });
      setUser(updatedUser);
    } catch (err) {
      console.error("Failed to upload photo:", err);
      // You could add a user-facing error message here
    } finally {
      setIsUploading(false);
    }
  };

  const handleRequestNotificationPermission = async () => {
    if (!('Notification' in window)) {
      toast.info("This browser does not support push notifications.");
      return;
    }

    if (Notification.permission === 'denied') {
        toast.info("Notifications are blocked. Please enable them in your browser or OS settings.");
        return;
    }

    if (Notification.permission === 'default') {
      try {
        const permission = await Notification.requestPermission();
        setNotificationPermission(permission);
        
        if (permission === 'granted') {
          toast.success("Notifications enabled!");
          new Notification("OyConnect", {
            body: "You'll now get alerts for new messages.",
            icon: "/favicon.ico"
          });
        }
      } catch (err) {
        console.error("Error requesting notification permission:", err);
        toast.error("Failed to request notification permission.");
      }
    }
  };

  const handleDiscoverabilityChange = async (isDiscoverable) => {
    setUser(prev => ({ ...prev, is_discoverable: isDiscoverable }));
    try {
        await User.updateMyUserData({ is_discoverable: isDiscoverable });
        
        if (isDiscoverable) {
            // Create or update DiscoveryProfile when opting in
            const existingProfiles = await DiscoveryProfile.filter({ user_id: user.id });
            const profileData = {
                user_id: user.id,
                first_name: user.first_name,
                age: user.age,
                city: user.city,
                profile_photo: user.profile_photo,
                vibe_tags: user.vibe_tags || [],
                interest_tags: user.interest_tags || [],
                verified: user.verified || false
            };
            
            if (existingProfiles.length > 0) {
                await DiscoveryProfile.update(existingProfiles[0].id, profileData);
            } else {
                await DiscoveryProfile.create(profileData);
            }
        } else {
            // Delete DiscoveryProfile when opting out
            const existingProfiles = await DiscoveryProfile.filter({ user_id: user.id });
            if (existingProfiles.length > 0) {
                await DiscoveryProfile.delete(existingProfiles[0].id);
            }
        }
        
        toast.success(`You are now ${isDiscoverable ? 'discoverable' : 'hidden'}.`);
    } catch(err) {
        toast.error("Failed to update setting.");
        // Revert UI on failure
        setUser(prev => ({ ...prev, is_discoverable: !isDiscoverable }));
    }
  };

  const handlePrivacyChange = async (key, value) => {
    setUser(prev => ({ ...prev, [key]: value }));
    try {
        await User.updateMyUserData({ [key]: value });
        toast.success("Privacy setting updated.");
    } catch(err) {
        toast.error("Failed to update setting.");
        // Revert UI on failure
        setUser(prev => ({ ...prev, [key]: !value }));
    }
  };

  if (!user) {
    return (
      <div className="max-w-2xl mx-auto p-4 space-y-4">
        <motion.div 
          className="flex items-center gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
            <Skeleton className="h-24 w-24 rounded-full shimmer"/>
            <div className="space-y-2">
                <Skeleton className="h-6 w-40 shimmer"/>
                <Skeleton className="h-4 w-60 shimmer"/>
            </div>
        </motion.div>
        <Skeleton className="h-96 w-full shimmer"/>
      </div>
    );
  }

  const formattedFirstName = formatName(user.first_name);
  const formattedLastName = formatName(user.last_name);
  const fullName = `${formattedFirstName} ${formattedLastName}`;

  return (
    <motion.div 
      className="max-w-2xl mx-auto p-4 space-y-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div>
        <div className="flex items-center gap-4 mb-6">
          <div
            className="relative group cursor-pointer"
            onClick={handleAvatarClick}
          >
            <OptimizedAvatar
              src={user.profile_photo}
              alt={formattedFirstName}
              fallbackText={formattedFirstName?.[0]}
              size="large"
              priority={true}
              className="h-24 w-24 border-4 border-primary/20 shadow-floating"
            />
            <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-200">
              {isUploading ? (
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-white border-t-transparent" />
              ) : (
                <Camera className="w-8 h-8 text-white" />
              )}
            </div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handlePhotoUpload}
              className="hidden"
              accept="image/*"
              disabled={isUploading}
            />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-foreground">
              {fullName}
            </h1>
            <p className="text-muted-foreground mt-1">{user.city} • Age {user.age}</p>
            {user.phone_number && (
              <p className="text-muted-foreground text-sm mt-1">
                WhatsApp: {user.phone_number}
              </p>
            )}
          </div>
        </div>
        <Button className="w-full hover-lift" variant="outline" disabled>
          <Edit className="w-4 h-4 mr-2" /> Edit Profile (Coming Soon)
        </Button>
      </div>

      <Card className="shadow-elegant border-border/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="p-2 bg-gradient-to-br from-primary/20 to-primary/10 rounded-lg">
              <Bell className="w-5 h-5 text-primary" />
            </div>
            Settings
          </CardTitle>
        </CardHeader>
        <CardContent>
             <SettingsRow 
                icon={<SearchCheck className="w-5 h-5"/>}
                title="Discoverable"
                subtitle={user.is_discoverable ? "You are visible on the Discover page" : "You are hidden from the Discover page"}
            >
              <Switch
                checked={!!user.is_discoverable}
                onCheckedChange={handleDiscoverabilityChange}
                aria-label="Toggle Discoverability"
              />
            </SettingsRow>
            
            <SettingsRow 
                icon={<Phone className="w-5 h-5"/>}
                title="Allow WhatsApp Unlock"
                subtitle={user.allow_mutual_unlock ? "Others can request to unlock your WhatsApp" : "WhatsApp unlock requests are disabled"}
            >
              <Switch
                checked={!!user.allow_mutual_unlock}
                onCheckedChange={(value) => handlePrivacyChange('allow_mutual_unlock', value)}
                aria-label="Toggle WhatsApp Unlock"
              />
            </SettingsRow>
            
            <SettingsRow 
                icon={<ShieldCheck className="w-5 h-5"/>}
                title="Show Number After Unlock"
                subtitle={user.show_number_after_unlock ? "Your number will be shown after mutual unlock" : "Your number will stay hidden even after unlock"}
            >
              <Switch
                checked={!!user.show_number_after_unlock}
                onCheckedChange={(value) => handlePrivacyChange('show_number_after_unlock', value)}
                aria-label="Toggle Show Number"
              />
            </SettingsRow>
            
             <SettingsRow 
                icon={<Bell className="w-5 h-5"/>}
                title="Notifications"
                subtitle={
                    notificationPermission === 'granted' ? "You'll be notified of new messages" :
                    notificationPermission === 'denied' ? (isMobile ? "Enable in browser settings" : "Blocked, change in browser settings") :
                    (isMobile ? "Enable push notifications" : "Enable browser notifications")
                }
                onClick={handleRequestNotificationPermission}
            >
              {notificationPermission === 'granted' && <CheckCircle2 className="w-5 h-5 text-green-500"/>}
              {notificationPermission === 'denied' && <XCircle className="w-5 h-5 text-destructive"/>}
              {notificationPermission === 'default' && <ChevronRight className="w-5 h-5 text-muted-foreground" />}
            </SettingsRow>
        </CardContent>
      </Card>
      
      <div className="pt-4 space-y-3">
         <Button onClick={handleLogout} variant="destructive" className="w-full hover-lift shadow-lg">
            <LogOut className="w-4 h-4 mr-2" /> Log Out
         </Button>
         <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" className="w-full border-destructive text-destructive hover:bg-destructive/10 hover:text-destructive">
                <Trash2 className="w-4 h-4 mr-2" /> Delete Profile
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete your account
                  and remove your data from our servers.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteProfile} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Delete Account
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
      </div>
    </motion.div>
  );
}
