import React, { useState, useEffect, useCallback } from "react";
import { Connection } from "@/api/entities";
import { User } from "@/api/entities";
import { DiscoveryProfile } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { MapPin, Users, RefreshCw, AlertTriangle, Heart, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import OptimizedImage from '../components/OptimizedImage';
import { getDiscoverableUsers } from "@/api/functions";

const ProfileCard = ({ profile, onConnect, onSkip, isConnecting, index }) => (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
      transition={{ delay: index * 0.05 }}
      className="w-full max-w-sm mx-auto"
    >
      <Card className="overflow-hidden hover:shadow-2xl transition-all duration-300 border-0 bg-gradient-to-br from-card to-card/90 shadow-xl">
        <div className="relative aspect-[3/4] overflow-hidden">
          <OptimizedImage src={profile.profile_photo} alt={profile.first_name} className="w-full h-full object-cover" priority={index < 2}/>
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
            <h3 className="text-2xl font-bold drop-shadow-lg">{profile.first_name}, {profile.age}</h3>
            <div className="flex items-center gap-2 text-sm opacity-90 my-2">
              <MapPin className="w-4 h-4" />
              <span>{profile.city}</span>
            </div>
            <div className="flex flex-wrap gap-1 mb-4">
              {profile.interest_tags?.slice(0, 3).map(tag => <Badge key={tag} variant="outline" className="border-white/30 text-white text-xs backdrop-blur-sm">{tag}</Badge>)}
            </div>
            <div className="flex gap-3 justify-center">
              <Button onClick={() => onSkip(profile)} variant="outline" size="lg" className="flex-1 bg-white/10 border-white/30 text-white hover:bg-white/20 backdrop-blur-sm"><X className="w-5 h-5 mr-2" />Skip</Button>
              <Button onClick={() => onConnect(profile)} disabled={isConnecting} size="lg" className="flex-1 bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary text-white shadow-lg hover:shadow-xl"><Heart className="w-5 h-5 mr-2" />{isConnecting ? 'Connecting...' : 'Connect'}</Button>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
);

const EmptyState = ({ message, onRefresh }) => (
    <motion.div className="text-center py-16" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}><div className="mx-auto w-24 h-24 bg-gradient-to-br from-primary/10 to-primary/5 rounded-full flex items-center justify-center mb-6"><Users className="w-12 h-12 text-primary/60" /></div><h3 className="text-xl font-semibold mb-2">No Profiles Found</h3><p className="text-muted-foreground mb-6 max-w-md mx-auto">{message}</p><Button onClick={onRefresh} variant="outline" className="gap-2"><RefreshCw className="w-4 h-4" />Try Again</Button></motion.div>
);

const ErrorState = ({ error, onRetry }) => (
    <motion.div className="text-center py-16" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}><div className="mx-auto w-24 h-24 bg-gradient-to-br from-red-100 to-red-50 rounded-full flex items-center justify-center mb-6"><AlertTriangle className="w-12 h-12 text-red-500" /></div><h3 className="text-xl font-semibold mb-2">Something Went Wrong</h3><p className="text-muted-foreground mb-6 max-w-md mx-auto">{error}</p><Button onClick={onRetry} className="gap-2"><RefreshCw className="w-4 h-4" />Try Again</Button></motion.div>
);

export default function DiscoverNewPage() {
    const [profiles, setProfiles] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [emptyMessage, setEmptyMessage] = useState('');
    const [isConnecting, setIsConnecting] = useState(false);
    const [currentUser, setCurrentUser] = useState(null);
    const [hasLoaded, setHasLoaded] = useState(false);

    // OPTIMIZATION: Only fetch profiles once when component mounts
    const fetchProfiles = useCallback(async () => {
        // Prevent multiple simultaneous fetches
        if (hasLoaded) return;
        
        setIsLoading(true);
        setError(null);
        try {
            const response = await getDiscoverableUsers();
            
            if (response.data.error) {
                if (response.data.details?.includes("Rate limit exceeded")) {
                     throw new Error("We're experiencing high traffic. Please try again in a moment.");
                }
                throw new Error(response.data.error);
            }

            const { profiles } = response.data;
            setProfiles(profiles);
            
            if (profiles.length === 0) {
                setEmptyMessage('No new profiles available right now. Check back later!');
            }
            
            setHasLoaded(true);

        } catch (err) {
            console.error("Error fetching profiles:", err);
            if (err.message.includes('500') || err.message.includes('Rate limit')) {
                setError("Could not load profiles due to high traffic. Please refresh in a moment.");
            } else {
                setError(err.message || "An unknown error occurred.");
            }
        } finally {
            setIsLoading(false);
        }
    }, [hasLoaded]);

    useEffect(() => {
        const initializePage = async () => {
            try {
                const user = await User.me();
                setCurrentUser(user);
                await fetchProfiles();
            } catch (err) {
                setError("Authentication failed. Please refresh.");
                setIsLoading(false);
            }
        };

        initializePage();
    }, []); // Only run once on mount

    const handleConnect = async (profile) => {
        if (!currentUser || isConnecting) return;

        if (profile.user_id && profile.user_id.toString().startsWith('sample_user_')) {
            toast.info("This is a sample profile.", {
                description: "You can't connect with sample profiles. This feature will work with real users.",
                duration: 5000,
            });
            return;
        }

        setIsConnecting(true);
        try {
            // OPTIMIZATION: Check for existing connections before creating new ones
            const existingConnections = await Connection.filter({
                participants: { $all: [currentUser.id, profile.user_id] }
            });
            
            if (existingConnections.length > 0) {
                toast.info(`You're already connected with ${profile.first_name}!`, {
                    description: "You can find them in your Chats.",
                });
                setProfiles(prev => prev.filter(p => p.id !== profile.id));
                return;
            }

            await Connection.create({ 
                participants: [currentUser.id, profile.user_id], 
                status: 'active' 
            });
            
            setProfiles(prev => prev.filter(p => p.id !== profile.id));
            toast.success(`Connected with ${profile.first_name}! 🎉`, {
                description: "You can now find them in your Chats.",
            });
        } catch (err) {
            console.error("Connection error:", err);
            toast.error("Failed to connect. Please try again.");
        } finally {
            setIsConnecting(false);
        }
    };

    const handleSkip = (profile) => {
        setProfiles(prev => prev.filter(p => p.id !== profile.id));
    };
    
    const handleRefresh = () => {
        setHasLoaded(false);
        setError(null);
        fetchProfiles();
    };

    if (!currentUser && isLoading) {
        return <div className="min-h-screen flex items-center justify-center"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>;
    }

    return (
        <div className="max-w-7xl mx-auto p-4 space-y-6">
            <motion.div className="text-center" initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent mb-2">Discover New People</h1>
                <p className="text-muted-foreground">Connect with amazing people in your community</p>
            </motion.div>

            {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">{[...Array(6)].map((_, i) => <Card key={i}><Skeleton className="aspect-[3/4] w-full" /><CardContent className="p-4"><Skeleton className="h-6 w-3/4 mb-2" /><Skeleton className="h-4 w-1/2" /></CardContent></Card>)}</div>
            ) : error ? <ErrorState error={error} onRetry={handleRefresh} />
              : profiles.length === 0 ? <EmptyState message={emptyMessage} onRefresh={handleRefresh} />
              : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                      <AnimatePresence>
                          {profiles.map((p, i) => <ProfileCard key={p.id} profile={p} onConnect={handleConnect} onSkip={handleSkip} isConnecting={isConnecting} index={i} />)}
                      </AnimatePresence>
                  </div>
              )
            }
        </div>
    );
}