
import React, { useState } from "react";
import { User } from "@/api/entities";
import { DiscoveryProfile } from "@/api/entities"; // Added this import
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { UploadFile } from "@/api/integrations";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ArrowRight, PartyPopper, Camera, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

const JEWISH_CONNECTION_TAGS = ["Friday night dinners", "Israel trip", "Summer camp", "Youth movement", "Jewish holidays", "Hebrew school", "TLV beach", "Community feel", "Learning Hebrew", "Family traditions", "Going to shul", "Zionism", "Culture & food", "Jewish friends", "Jewish school"];
const HERE_FOR_TAGS = ["Chill conversations", "New mates", "Events & meetups", "Jewish connection", "See what happens", "Something meaningful", "Good chats"];
const FRIENDS_DESCRIBE_TAGS = ["Down to earth", "Funny", "Thoughtful", "Social", "Creative", "Adventurous", "Reliable", "Laid-back", "Good listener", "Energetic", "Smart", "Supportive", "Up for anything"];
const INTEREST_TAGS = ["Football", "Basketball", "Rugby", "Gym", "Cricket", "Tennis", "Travelling", "Cooking", "Music", "Playing an instrument", "Going to gigs", "Photography", "Art", "Fashion", "Podcasts", "Debating", "Drama & theatre", "Jewish summer camps", "Youth group life", "Zionism", "Learning Hebrew", "Summer plans", "Making plans that actually happen"];

const TagSelector = ({ tags, selectedTags, setSelectedTags, max, title, description, singleSelection = false }) => (
  <div>
    <h3 className="text-xl font-semibold text-foreground">{title}</h3>
    <p className="text-muted-foreground mb-4">{description}</p>
    <div className="flex flex-wrap gap-2">
      {tags.map(tag => {
        const isSelected = selectedTags.includes(tag);
        return (
          <Button
            key={tag}
            variant={isSelected ? "default" : "outline"}
            className={`rounded-full transition-all duration-200 ${isSelected ? 'bg-primary text-primary-foreground hover:bg-primary/90' : 'bg-card hover:bg-accent'}`}
            onClick={() => {
              if (singleSelection) {
                setSelectedTags([tag]);
              } else {
                if (isSelected) {
                  setSelectedTags(selectedTags.filter(t => t !== tag));
                } else if (selectedTags.length < max) {
                  setSelectedTags([...selectedTags, tag]);
                }
              }
            }}
          >
            {tag}
          </Button>
        );
      })}
    </div>
  </div>
);

export default function OnboardingPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [userData, setUserData] = useState({
    first_name: "",
    last_name: "",
    dob: "",
    age: 0,
    city: "",
    phone_number: "",
    profile_photo: "",
    here_for: [],
    jewish_connection: [],
    vibe_tags: [], // Will store "How would your friends describe you?"
    interest_tags: [],
  });

  const totalSteps = 7;

  const handleNext = async () => {
    setError('');
    let valid = true;
    switch(step) {
        case 1: // Basic Info
            if(!userData.first_name || !userData.last_name || !userData.dob || !userData.city || !userData.phone_number) {
                valid = false;
                setError("Please fill in all your details, including your phone number.");
                break;
            }
            const birthDate = new Date(userData.dob);
            const today = new Date();
            let age = today.getFullYear() - birthDate.getFullYear();
            const m = today.getMonth() - birthDate.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) { age--; }
            if (age < 15 || age > 18) {
                valid = false;
                setError("Sorry, you must be between 15 and 18 to join.");
            } else {
                setUserData({...userData, age});
            }
            break;
        case 2: // Profile Photo
            if(!userData.profile_photo) {
                valid = false;
                setError("A profile photo is required.");
            }
            break;
        case 3: // Jewish Connection
            if(userData.jewish_connection.length === 0) {
                valid = false;
                setError("Please make at least one selection.");
            }
            break;
        case 4: // Here For
             if(userData.here_for.length === 0) {
                valid = false;
                setError("Please make at least one selection.");
            }
            break;
        case 5: // Friends Describe
            if(userData.vibe_tags.length !== 3) {
                valid = false;
                setError("Please select exactly 3 options.");
            }
            break;
        case 6: // Interests
            if(userData.interest_tags.length !== 5) {
                valid = false;
                setError("Please select exactly 5 interests.");
            }
            break;
    }

    if (valid) {
      if (step === totalSteps - 1) { // Finishing step
        setIsSubmitting(true);
        const toastId = toast.loading("Saving your profile...");
        
        try {
          // Save to User entity
          await User.updateMyUserData({ 
            ...userData, 
            onboarding_complete: true,
            is_discoverable: true // Auto opt-in to discovery
          });
          
          // Create DiscoveryProfile
          const currentUser = await User.me();
          await DiscoveryProfile.create({
            user_id: currentUser.id,
            first_name: userData.first_name,
            age: userData.age,
            city: userData.city,
            profile_photo: userData.profile_photo,
            vibe_tags: userData.vibe_tags,
            interest_tags: userData.interest_tags,
            verified: false
          });
          
          toast.success("Profile complete! Welcome to OyConnect.", { id: toastId });
          navigate(createPageUrl("DiscoverNew"));

        } catch (err) { 
          console.error("ONBOARDING: CRITICAL ERROR on final step:", err);
          toast.error("Something went wrong", { 
              description: `Could not save your profile. Please try again. Error: ${err.message}`,
              duration: 10000,
              id: toastId 
          });
          setError(`Error: ${err.message}. Please try again.`); 
          setIsSubmitting(false);
        }
      } else {
        setStep(prev => prev + 1);
      }
    }
  };
  
  const handlePhotoUpload = async (e) => {
      const file = e.target.files[0];
      if (file) {
          setIsUploading(true);
          setError('');
          try {
              const { file_url } = await UploadFile({ file });
              setUserData(prev => ({...prev, profile_photo: file_url}));
          } catch (err) { setError("Failed to upload photo. Please try again."); } 
          finally { setIsUploading(false); }
      }
  }
  
  const renderStep = () => {
      switch(step) {
          case 1: return (
              <div>
                  <h3 className="text-xl font-semibold text-foreground mb-4">Let’s start simple — what should we call you?</h3>
                  <div className="space-y-4">
                      <Input type="text" placeholder="First Name" value={userData.first_name} onChange={e => setUserData({...userData, first_name: e.target.value})} className="text-lg p-6"/>
                      <Input type="text" placeholder="Last Name" value={userData.last_name} onChange={e => setUserData({...userData, last_name: e.target.value})} className="text-lg p-6"/>
                      <Input type="date" value={userData.dob} onChange={e => setUserData({...userData, dob: e.target.value})} className="text-lg p-6 w-full"/>
                      <Input type="text" placeholder="City" value={userData.city} onChange={e => setUserData({...userData, city: e.target.value})} className="text-lg p-6"/>
                      <Input type="tel" placeholder="Phone Number (for WhatsApp)" value={userData.phone_number} onChange={e => setUserData({...userData, phone_number: e.target.value})} className="text-lg p-6"/>
                  </div>
              </div>
          );
          case 2: return (
              <div>
                  <h3 className="text-xl font-semibold text-foreground">Upload a photo where people can see who you are</h3>
                  <p className="text-muted-foreground mb-4">clear, recent, and just you.</p>
                  <Input id="photo-upload" type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden"/>
                  <label htmlFor="photo-upload" className="cursor-pointer flex flex-col items-center justify-center gap-2 w-full p-10 border-2 border-dashed border-border rounded-lg bg-accent">
                      <Camera className="w-8 h-8 text-primary"/>
                      <span className="font-semibold">{isUploading ? "Uploading..." : (userData.profile_photo ? "Photo Selected!" : "Choose Photo")}</span>
                  </label>
                  {userData.profile_photo && <img src={userData.profile_photo} alt="Preview" className="mt-4 rounded-lg w-32 h-32 object-cover mx-auto"/>}
              </div>
          );
          case 3: return (
              <TagSelector tags={JEWISH_CONNECTION_TAGS} selectedTags={userData.jewish_connection} setSelectedTags={tags => setUserData({...userData, jewish_connection: tags})} max={3} title="What connects you to being Jewish?" description="Pick up to 3 that match your experience" />
          );
          case 4: return (
              <TagSelector tags={HERE_FOR_TAGS} selectedTags={userData.here_for} setSelectedTags={tags => setUserData({...userData, here_for: tags})} max={2} title="Why are you on OyConnect?" description="Pick 1 or 2 — be real with it" />
          );
          case 5: return (
              <TagSelector tags={FRIENDS_DESCRIBE_TAGS} selectedTags={userData.vibe_tags} setSelectedTags={tags => setUserData({...userData, vibe_tags: tags})} max={3} title="How would your friends describe you?" description="Pick 3" />
          );
          case 6: return (
              <TagSelector tags={INTEREST_TAGS} selectedTags={userData.interest_tags} setSelectedTags={tags => setUserData({...userData, interest_tags: tags})} max={5} title="What are you genuinely into?" description="Choose exactly 5" />
          );
          default: return null;
      }
  }

  return (
    <div className="min-h-screen bg-background p-4 flex items-center justify-center">
      <Card className="w-full max-w-2xl shadow-lg border-border bg-card">
        <CardHeader>
          <Progress value={(step / (totalSteps-1)) * 100} className="[&>*]:bg-primary mb-4" />
          <CardTitle className="text-primary text-center text-3xl font-bold">Welcome to OyConnect!</CardTitle>
          <CardDescription className="text-center">Just a few steps to get you set up.</CardDescription>
        </CardHeader>
        <CardContent>
          <AnimatePresence mode="wait">
            <motion.div key={step} initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} transition={{ duration: 0.3 }} className="my-8 min-h-[200px]">
              {renderStep()}
            </motion.div>
          </AnimatePresence>
          {error && <p className="text-red-500 text-sm text-center my-2 flex items-center justify-center gap-2"><AlertCircle className="w-4 h-4"/> {error}</p>}
          <div className="flex justify-end mt-8">
            <Button onClick={handleNext} size="lg" disabled={isSubmitting || isUploading} className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-8 py-6 text-lg">
              {isSubmitting ? "Saving..." : (isUploading ? "Uploading..." : (step < totalSteps - 1 ? "Continue" : "Let's Go!"))}
              {!isSubmitting && !isUploading && (step < totalSteps - 1 ? <ArrowRight className="ml-2 w-5 h-5"/> : <PartyPopper className="ml-2 w-5 h-5"/>)}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
