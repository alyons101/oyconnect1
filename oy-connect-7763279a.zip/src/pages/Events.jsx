import React, { useState, useEffect } from "react";
import { Event } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus, Calendar, MapPin, Clock } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

const EventSubmissionForm = ({ onFinish }) => {
    const [eventData, setEventData] = useState({ title: '', description: '', date: '', location: '', organizer: '' });
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        try {
            const currentUser = await User.me();
            await Event.create({ ...eventData, submitted_by: currentUser.id, approved: false });
            onFinish();
        } catch (error) {
            console.error("Failed to submit event", error);
        } finally {
            setIsSubmitting(false);
        }
    };
    
    const handleChange = (e) => {
        const { id, value } = e.target;
        setEventData(prev => ({...prev, [id]: value}));
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <Label htmlFor="title">Event Title</Label>
                <Input id="title" value={eventData.title} onChange={handleChange} required/>
            </div>
            <div>
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" value={eventData.description} onChange={handleChange} required/>
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <Label htmlFor="date">Date & Time</Label>
                    <Input id="date" type="datetime-local" value={eventData.date} onChange={handleChange} required/>
                </div>
                <div>
                    <Label htmlFor="location">Location</Label>
                    <Input id="location" value={eventData.location} onChange={handleChange} placeholder="e.g., JW3, London" required/>
                </div>
            </div>
            <div>
                <Label htmlFor="organizer">Organizer</Label>
                <Input id="organizer" value={eventData.organizer} onChange={handleChange} placeholder="e.g., Your Youth Group" required/>
            </div>
            <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? 'Submitting...' : 'Submit for Approval'}
            </Button>
        </form>
    );
};

const ComingSoonTeaser = () => {
    const nextSunday = new Date();
    nextSunday.setDate(nextSunday.getDate() + (7 - nextSunday.getDay()));
    
    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-12"
        >
            <Card className="max-w-md mx-auto bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
                <CardHeader>
                    <div className="w-16 h-16 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Calendar className="w-8 h-8 text-primary-foreground" />
                    </div>
                    <CardTitle className="text-2xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
                        Events Coming Soon
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="p-4 bg-card rounded-lg border border-border/50">
                        <div className="flex items-center justify-between mb-2">
                            <h3 className="font-bold text-lg">Hampstead House Party</h3>
                            <Badge className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground">
                                Soon
                            </Badge>
                        </div>
                        <div className="space-y-2 text-sm text-muted-foreground">
                            <div className="flex items-center gap-2">
                                <Calendar className="w-4 h-4" />
                                <span>Sunday, {nextSunday.toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <Clock className="w-4 h-4" />
                                <span>11:00 PM</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <MapPin className="w-4 h-4" />
                                <span>Hampstead, London</span>
                            </div>
                        </div>
                        <p className="text-sm text-foreground/80 mt-3">
                            Get ready for an epic night! More details coming soon...
                        </p>
                    </div>
                    <p className="text-muted-foreground text-sm">
                        Events feature launching soon! Submit your own events below to get them reviewed for the community.
                    </p>
                </CardContent>
            </Card>
        </motion.div>
    );
};

export default function EventsPage() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);
  
  const handleFormFinished = () => {
      setIsFormOpen(false);
  }

  return (
    <div className={`mx-auto p-4 ${isMobile ? 'max-w-none' : 'max-w-4xl'}`}>
      <div className={`flex ${isMobile ? 'flex-col gap-4' : 'flex-row'} justify-between items-center mb-8`}>
        <h1 className={`font-bold ${isMobile ? 'text-2xl' : 'text-3xl'}`}>Events</h1>
         <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
            <DialogTrigger asChild>
                <Button className={isMobile ? 'w-full' : ''}>
                    <Plus className="w-4 h-4 mr-2" /> Submit Event
                </Button>
            </DialogTrigger>
            <DialogContent className={isMobile ? 'w-[95vw] max-w-[95vw]' : ''}>
                <DialogHeader>
                    <DialogTitle>Submit a Community Event</DialogTitle>
                </DialogHeader>
                <p className="text-sm text-muted-foreground -mt-2 mb-4">Your event will be reviewed by an admin before it's published.</p>
                <EventSubmissionForm onFinish={handleFormFinished}/>
            </DialogContent>
        </Dialog>
      </div>

      <ComingSoonTeaser />
    </div>
  );
}